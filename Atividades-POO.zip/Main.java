public class Main {
    public static void main(String[] args) {
        Racional r1 = new Racional(1, 2); // Cria um número racional 1/2
        Racional r2 = new Racional(3, 4); // Cria um número racional 3/4

        // Testa os métodos implementados e exibe os resultados
        System.out.println("r1: " + r1); // Exibe 1/2
        System.out.println("r2: " + r2); // Exibe 3/4

        Racional soma = r1.somar(r2);
        Racional subtracao = r1.subtrair(r2);
        Racional multiplicacao = r1.multiplicar(r2);
        Racional divisao = r1.dividir(r2);

        System.out.println("Soma: " + soma); // Exibe 5/4
        System.out.println("Subtração: " + subtracao); // Exibe -1/4
        System.out.println("Multiplicação: " + multiplicacao); // Exibe 3/8
        System.out.println("Divisão: " + divisao); // Exibe 2/3

        System.out.println("Valor real de r1: " + r1.valorReal()); // Exibe 0.5
        System.out.println("r1 igual a r2? " + r1.igual_a(r2)); // Exibe false
        System.out.println("r1 menor que r2? " + r1.menor_que(r2)); // Exibe true
    }
}
